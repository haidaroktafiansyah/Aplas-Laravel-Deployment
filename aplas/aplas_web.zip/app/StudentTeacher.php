<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentTeacher extends Model
{
  protected $table='student_teachers';

  public $primaryKey='id';
}
