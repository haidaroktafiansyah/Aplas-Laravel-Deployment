<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentValidation extends Model
{
  protected $table='student_validations';

  public $primaryKey='id';
}
