<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TaskResult extends Model
{
  protected $table='task_results';
  public $primaryKey='id';
}
