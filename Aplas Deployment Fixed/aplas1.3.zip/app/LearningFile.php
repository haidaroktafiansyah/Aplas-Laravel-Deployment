<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LearningFile extends Model
{
  protected $table='learning_files';
  public $primaryKey='id';
}
