<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentSubmit extends Model
{
  protected $table='student_submits';

  public $primaryKey='id';
}
